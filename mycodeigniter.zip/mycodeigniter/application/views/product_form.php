<?php echo form_open('product/save') ?>
<table>
	<tr>
		<td>ID</td>
		<td><?php echo form_input('item_id','',array('placeholder'=>'Item ID')) ?></td>
	</tr>
	<tr>
		<td>NAME</td>
		<td><?php echo form_input('item_name','',array('placeholder'=>'Name')) ?></td>
	</tr>
	<tr>
		<td>NOTE</td>
		<td><?php echo form_textarea('item_note','',array('placeholder'=>'Note')) ?></td>
	</tr>		
	<tr>
		<td>PRICE</td>
		<td><?php echo form_input('item_price','',array('placeholder'=>'Price')) ?></td>
	</tr>
	<tr>
		<td>STOCK</td>
		<td><?php echo form_input('item_stock','',array('placeholder'=>'Stock')) ?></td>
	</tr>
	<tr>
		<td>UNIT</td>
		<td><?php echo form_input('item_unit','',array('placeholder'=>'Unit Name')) ?></td>
	</tr>
	<tr>
		<td colspan="2"> <hr><?php echo form_submit('submit', 'Save Item!'); ?> <?php echo anchor('product','Back') ?></td>
	</tr>
</table>
<?php echo form_close(); ?>