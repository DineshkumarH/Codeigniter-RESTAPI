<?php
class Product extends  CI_Controller {
	public function index(){
		$this->load->model('product_model');
		$data['product_list'] = $this->product_model->list_product();
		$data['title'] = "Product";
		$this->load->view('product_list',$data);
	}
	public function add()
	{
		$this->load->view('product_form');
	}
	public function save()
	{
		$array_item = array(
			'item_id' => $this->input->post('item_id'),
			'item_name' => $this->input->post('item_name'),
			'item_note' => $this->input->post('item_note'),
			'item_stock' => $this->input->post('item_stock'),
			'item_price' => $this->input->post('item_price'),
			'item_unit' => $this->input->post('item_unit')
			);
		$this->load->model('product_model');
		$save = $this->product_model->save($array_item);
		if($save)
		{
			$this->session->set_flashdata('hasil','Insert Data Berhasil');
		}else
		{
			$this->session->set_flashdata('hasil','Insert Data Gagal');
		}
		redirect('product');
	}
	public function save_edit()
	{
		$array_item = array(
			'item_id' =>$this->input->post('item_id'),
			'item_name' => $this->input->post('item_name'),
			'note' => $this->input->post('item_note'),
			'stock' => $this->input->post('item_stock'),
			'price' => $this->input->post('item_price'),
			'unit' => $this->input->post('item_unit')
			);
		$this->load->model('product_model');
		$this->product_model->update($array_item);
		redirect('product');
	}
	public function edit(){
		$this->load->model('product_model');
		$data['product'] = $this->product_model->product($this->uri->segment(3))[0];
		$this->load->view('product_edit',$data);
	}
	public function delete()
	{
		$id = $this->uri->segment(3);
		$this->load->model('product_model');
		$this->product_model->delete($id);
		redirect('product');
	}
}